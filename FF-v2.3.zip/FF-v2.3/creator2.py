from py2pddl import Domain, create_type 
from py2pddl import predicate, action, goal, init 
import numpy as np 
import mahotas 
import matplotlib.pyplot as plt


def render(poly):
	 """Return polygon as grid of points inside polygon.
	 Input : poly (list of lists) 
	 Output : output (list of lists),
	 """
	 xs,ys = zip(*poly)
	 minx, maxx = min (xs), max(xs)
	 miny, maxy = min (ys), max(ys)
	 newPoly = [(int(x - minx), int(y - miny)) for (x, y) in poly]
	 X = maxx - minx + 1
	 Y = maxy - miny + 1
	 grid = np.zeros((X, Y), dtype=np.int8)
	 mahotas.polygon.fill_polygon (newPoly, grid)
	 
	 return [(x + minx, y + miny) for (x, y) in zip(*np.nonzero(grid))]
	 
	 
class Farmbot (Domain) :
	Waypoint = create_type("Waypoint")
	Robot = create_type ("Robot")
	Sample = create_type ("Sample")
	Seed = create_type ("Seed") 
	Weed = create_type ("Weed")
	Arm = create_type ("Arm")
	
	Camera = create_type("Camera")
	SoilSensor = create_type("SoilSensor")
	SeedInj = create_type("SeedInjector")
	Weeder = create_type("Weeder")
	WateringNozzle = create_type("WateringNozzle")
	
	@predicate (Sample, Waypoint) 
	def is_visible(self, s, w):
	    """Complete the method signature and specify the respective types in the decorator"""
	@predicate (Sample, Waypoint)
	def is_in(self, s, w):
	    "Complete the method signature and specify the respective types in the decorator"
	@predicate (Weed, Waypoint)
	def is_(self, weed, w):
	    "" "Complete the method signature and specify the respective types in the decorator"
	@predicate (Robot, Sample)
	def carry(self, r, s):
	    """Complete the method signature and specify the respective types in the decorator"""
	@predicate (Robot, Waypoint)
	def at(self, r, w):
		"Complete the method signature and specify the respective types in the decorator"
	@predicate (Waypoint)
	def is_dropping_point (self, w):
		"" "Complete the method signature and specify the respective types in the decorator"
	@predicate (Sample)
	def taken_image (self, s):
		"" "Complete the method signature and specify the respective types in the decorator"
	@predicate (Sample)
	def taken_data(self, s):
		"Complete the method signature and specify the respective types in the decorator"
	@predicate (Sample)
	def stored_sample(self, s):
		"" "Complete the method signature and specify the respective types in the decorator"
	@predicate(Arm) 
	def empty(self, a):
		"" "Complete the method signature and specify the respective types in the decorator"""
	@predicate(Arm)
	def arm_down(self, a):
		"""Complete the method signature and specify the respective types in the decorator"""
	@predicate(Arm)
	def arm_up (self, a):
		"""Complete the method signature and specify the respective types in the decorator"""
	@predicate (Camera)
	def use_camera(self, C):
		"" "Complete the method signature and specify the respective types in the decorator"""
	@predicate(SoilSensor)
	def use_sensor(self, ss):
		"" "Complete the method signature and specify the respective types in the decorator"""
	@predicate (SeedInj)
	def use_seedinj (self, si):
		"" "Complete the method signature and specify the respective types in the decorator"""
	@predicate (Seed, Waypoint)
	def seedinjected(self, se, w):
		"Complete the method signature and specify the respective types in the decorator"""
	@predicate (Weeder)
	def use_weeder (self, we) :
		"" "Complete the method signature and specify the respective types in the decorator"""
	@predicate (Sample, Weed)
	def samplewithoutweed(self, s, weed):
		"" "Complete the method signature and specify the respective types in the decorator"""
	@predicate (WateringNozzle)
	def use_nozzle (self, wn) :
		"" "Complete the method signature and specify the respective types in the decorator"""
	@predicate (Sample)
	def samplewatered(self, s):
		"Complete the method signature and specify the respective types in the decorator"
	@predicate (Waypoint)
	def empty_wayp (self, w):
		"""Complete the method signature and specify the respective types in the decorator"""
	@action(Robot, Waypoint, Waypoint) 
	def move (self, r, w_from, w_to):
		precond: list = [self.at(r, w_from)]
		effect: list = [~self.at(r, w_from), self.at(r, w_to)]
		return precond, effect
	@action (Robot, Arm, Sample, Waypoint)
	def take_sample(self, r, a, s, w):
		precond: list = [self.is_in(s, w), self.at(r, w), self.empty(a), self.arm_up(a)]
		effect: list = [~self.is_in(s, w), self.carry(r, s), ~self.empty(a), self.arm_down (a)]
		return precond, effect
		
	@action (Robot, Arm, Sample, Waypoint)
	def drop_sample(self, r, a, s, w): 
		precond: list = [self.is_dropping_point(w), self.at(r, w), self.carry(r, s), ~self.empty(a),self.arm_down (a)]
		effect: list = [~self.carry(r, s),self.is_in(s, w), self.stored_sample(s), self.empty(a), self.arm_up (a)]
		return precond, effect
		    
	@action (Robot, Sample, Waypoint, Camera)
	def take_image (self, r, s, w, c):
		precond: list = [self.at(r, w), self.is_in(s, w), self.is_visible(s, w) ]
		effect: list = [self.use_camera(c), self.taken_image(s)]
		return precond, effect
		    
	@action(Seed, Waypoint, Robot, Arm, SeedInj)
	def inject_seed ( self, se, w, r, a, si):
		precond: list = [self.empty_wayp (w), self.at(r, w), self.arm_up (a)]
		effect: list = [self.arm_down (a), self.use_seedinj (si), self.seedinjected(se, w),~self.empty_wayp (w)]
		return precond, effect
		
	@action(Sample, Waypoint, Robot, Arm, Weeder, Weed)
	def eliminate_weed ( self, s, w, r, a, we, weed):
		precond: list = [self.is_in(s, w), self.is_(weed, w), self.at(r, w), self.arm_up (a)]
		effect: list = [self.arm_down (a), self.use_weeder (we), ~self.is_(weed, w),self.samplewithoutweed(s, weed), self.is_in(s, w)]
		return precond, effect
		
	@action(Sample, Waypoint, Robot, Arm, SoilSensor)
	def take_data(self, s, w, r, a, ss):
		precond: list = [self.is_in(s, w), self.at(r, w), self.arm_up (a)]
		effect: list = [self.arm_down (a), self.use_sensor(ss), self.taken_data(s)]
		return precond, effect
		
	@action (Sample, Waypoint, Robot, Arm, WateringNozzle)
	def water(self, s, w, r, a, wn) :
		precond: list = [self.is_in(s, w), self.at(r, w), self.arm_up (a)]
		effect: list = [self.arm_down (a), self.use_nozzle (wn), self.samplewatered(s)]
		return precond, effect




class MotionAndPictureProblem(Farmbot):
    def __init__(self):
        "To fill in"
        super().__init__()
        self.samples = Farmbot.Sample.create_objs(["A", "B", "C", "D", "E", "F", "G","H", "I"])
        self.seeds = Farmbot.Seed.create_objs(["seed1", "seed2", "seed3"])
        self.weeds = Farmbot.Weed.create_objs(["weed1", "weed2"])
        self.robot = Farmbot.Robot.create_objs(["robot"])
        self.arm = Farmbot.Arm.create_objs(["arm"])
        self.camera = Farmbot.Camera.create_objs(["camera"])
        self.seedinj = Farmbot.SeedInj.create_objs(["seedinj"])
        self.wateringnozzle = Farmbot.WateringNozzle.create_objs(["wateringnozzle"])
        self.weeder = Farmbot.Weeder.create_objs(["weeder"])
        self.soilsensor = Farmbot.SoilSensor.create_objs(["soilsensor"])
        poly = [[0,1],[0,3],[6,3],[6,1]]
        plt.figure(None, (7,7))
        x,y = zip(*render(poly))
        plt.scatter(x, y)
        n = 18
        a = []
        for i in range(n):
            points_coord = (x[i],y[i])
            a.append(points_coord)
            
        a0 = a[0] 
        a1 = a[1] 
        a2 = a[2] 
        a3 = a[3]
        a4= a[4] 
        a5 = a[5] 
        a6 = a[6] 
        a7 = a[7]
        a8 = a[8]
        a9 = a[9]
        a10 = a[10]
        a11 = a[11]
        a12 = a[12]
        a13 = a[13]
        a14 = a[14]
        a15 = a[15]
        a16 = a[16]
        a17 = a[17]
        self.waypoints = Farmbot.Waypoint.create_objs ( ["a0", "a1", "a2","a3", "a4", "a5", "a6", "a7","a8", "a9","a10","a11", "a12", "a13","a14","a15","a16","a17"])
         
    @init
    def init(self) -> list:
        at = [
        self.at(self.robot["robot"], self.waypoints["a0"]),
        self.is_dropping_point(self.waypoints["a17"]),
        self.is_in(self.samples["A"], self.waypoints["a1"]),
        self.is_in(self.samples["B"], self.waypoints["a3"]),
        self.is_in(self.samples ["C"], self.waypoints ["a4"]),
        self.is_in (self.samples["B"], self.waypoints["a3"]),
        self.is_in (self.samples["C"], self.waypoints["a4"]),
        self.is_in(self.samples["D"], self.waypoints["a5"]),
        self.is_in (self.samples["E"], self.waypoints["a7"]),
        self.is_in(self.samples["F"], self.waypoints["a8"]),
        self.is_in (self.samples["G"], self.waypoints["a11"]), 
        self.is_in(self.samples["H"], self.waypoints["a14"]),
        self.is_in(self.samples["I"], self.waypoints["a15"]),
        self.is_(self.weeds ["weed1"], self.waypoints["a3"]),
        self.is_(self.weeds ["weed2"], self.waypoints["a14"]),
        self.is_visible(self.samples["A"], self.waypoints["a1"]),
        self.is_visible(self.samples["B"], self.waypoints["a3"]),
        self.is_visible(self.samples ["C"], self.waypoints["a4"]),
        self.is_visible(self.samples["D"], self.waypoints["a5"]),
        self.is_visible(self.samples ["E"], self.waypoints["a7"]),
        self.is_visible(self. samples ["F"], self.waypoints["a8"]),
        self.is_visible(self.samples ["G"], self.waypoints["a11"]),
        self.is_visible(self.samples["H"], self.waypoints["a14"]),
        self.is_visible(self.samples["I"], self.waypoints ["a15"]),
                    
        self.empty_wayp (self.waypoints ["a0"]),
        self.empty_wayp (self.waypoints ["a2"]),
        self.empty_wayp (self.waypoints ["a6"]),
        self.empty_wayp (self.waypoints ["a9"]),
        self.empty_wayp (self.waypoints["a10"]),
        self.empty_wayp (self.waypoints ["a12"]),
        self.empty_wayp (self.waypoints ["a13"]),
        self.empty_wayp (self.waypoints["a16"]),
        self.empty_wayp (self.waypoints["a17"]),
                    
        self.empty(self.arm["arm"]),
        self.arm_up (self.arm["arm"]),
                    
        ]
        return at

    @goal 
    def goal(self) -> list:
        return [self.at (self.robot["robot"], self.waypoints["a0"]),
        self.taken_image(self.samples["A"]), self.taken_image (self.samples ["B"]),
        self.taken_image(self.samples["C"]), self.taken_image (self.samples ["D"]),
        self.taken_image(self.samples["E"]), self.taken_image(self.samples ["F"]),
        self.taken_image(self.samples ["G"]), self.taken_image(self.samples ["H"]),
        self.taken_image (self.samples ["I"]),
        self.taken_data(self.samples["A"]), self.taken_data(self.samples ["B"]),
        self.taken_data (self.samples ["C"]), self.taken_data(self.samples ["D"]),
        self.taken_data(self.samples["E"]), self.taken_data(self.samples ["F"]),
        self.taken_data( self.samples["G"]), self.taken_data(self.samples ["H"]),
        self.taken_data (self.samples ["I"]),
        self.samplewatered(self.samples["A"]), self.samplewatered ( self.samples ["B"]),
        self.samplewatered(self.samples ["C"]), self.samplewatered(self.samples ["D"]),
        self.samplewatered( self.samples["E"]), self.samplewatered(self.samples ["F"]),
        self.samplewatered( self.samples ["G"]), self.samplewatered(self.samples["H"]),
        self.samplewatered(self.samples ["I"]),
        self.seedinjected(self.seeds ["seed1"], self.waypoints ["a13"]),
        self.seedinjected(self.seeds ["seed2"], self.waypoints ["a16"]),
        self.seedinjected(self.seeds ["seed3"], self.waypoints ["a9"]),
        self.samplewithoutweed ( self.samples["B"], self.weeds["weed1"]),
        self.samplewithoutweed(self.samples["H"], self.weeds ["weed2"]),
        self.stored_sample(self. samples ["A"])]
    
